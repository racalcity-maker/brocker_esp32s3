#pragma once

const char *web_ui_get_index_html(void);

