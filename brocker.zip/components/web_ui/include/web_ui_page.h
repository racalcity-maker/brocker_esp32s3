#pragma once

const char *web_ui_get_index_html(void);
const char *web_ui_get_login_html(void);

