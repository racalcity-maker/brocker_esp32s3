void broker_config_dummy(void) {}
